Collection name: Gloss Basic Icons
Author: Momentum
Author homepage: http://www.momentumdesignlab.com/
Services: Design service for custom icons.
License: CC Attribution-Share Alike 3.0 United States
License URL: http://creativecommons.org/licenses/by-sa/3.0/us/
License description: This set is totally and completely free, for personal and commerical use under the Attribution-Share Alike 3.0 United States license as you include a link back to http://www.momentumdesignlab.com at least once in your credits. You may not, however, use these icons in products for resale, including but not limited to software applications, icon sets, templates (website, print, flash, video, etc.) and commercial games. Please contact us for extended licensing.
Commercial usage: Allowed