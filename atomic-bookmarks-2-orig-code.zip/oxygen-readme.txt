Oxygen icon theme is dual licensed. You may copy it under the Creative Common Attribution-ShareAlike 3.0 License or the GNU Library General Public License.

Author homepage: http://www.oxygen-icons.org/
License URL: http://creativecommons.org/licenses/by-sa/3.0/ or http://www.gnu.org/licenses/lgpl.html
